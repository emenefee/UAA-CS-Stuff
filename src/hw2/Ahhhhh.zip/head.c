/*  Elysha Menefee & Matt Hakin  */
/* CSCE A321 - Operating Systems */
/*         Date: 10/1/2019       */
/*    Last Revised: 9/22/2019    */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

// TODO: malloc into buffer, read into allocatedmem... coordinate memory 
// 			freeing and deleting itself

void echo()
{
	printf("echo / -e");
	// Handle how -e works here
	// Echo next bit of string input. Parse it
}

void lineNumber()
{
	printf("n / -n");
	// Handle how -n works here
}

void noArgs()
{
	// If there are no arguments, incurr the wrath of Icarus
	// But actually, take the first 10 lines of user input
}

// openFile()
// Purpose: Check to see if a file has the ability to be open
// Uses: open() with inputs of the name of the file as well as a read only parameter
// Inputs: char array that holds the address of a file
// Outputs: a file descriptor depicting the status of a file(
//			-1 if failed, non-negative if success)
int openFile(char fileName[]);

// closeFile()
// Purpose: Close file
// Uses:
// Inputs: File descriptor from open file
// Outputs: 0 on success, -1 on fail
int closeFile(int fd);

// sizeOfFile()
// Purpose: Obtain size of file, if file exists
// Inputs: char array that holds the address of a file
// Outputs: 0 if failed, size of file if success
int sizeOfFile(char file[]);

int getBytes(int fd, int start)
{
	bool done = false;
	int byteCount = start;
	int readItem = 0;
	char buffer[1];
	char *val2 = "\n";
	char *val3 = "\0";

	while(!done)
	{
		lseek(fd, byteCount, SEEK_SET);
		readItem = read(fd, buffer, 1); // read returns the NEXT byte
		char *val = buffer;
		if(*val == *val2 || *val == *val3 || buffer == EOF)
			done = true;
		byteCount++;
	}
	return byteCount;
}

void readLine(int fd, char buffer[], int bytesToRead)
{

	read(fd, buffer, bytes - currBytes);
}

// str_len()
// Purpose: Get the length of a given array
// Input: An array
// Output: length of array
size_t str_len(const char *str);

// printStuff()
// Purpose: Print a char array to display
// Input: A char array that you want to display
// Output: NA
void printStuff(char *msg);

// printData()
// Purpose: Print data from a buffer to display
// Input: A buffer, an integer that contains the length of the buffer
void printData(char *buffer, int len);

bool strCompare(char argStr[], char checkStr[]);

int strToInt(char argStr[]);

// Best knowledge, will work for everything starting with ./head
int main(int argc, char *argv[])
{
	char numStr[] = "-n";
	char echoStr[] = "-e";

	for(int i = 1; i < argc; i++) // for the arguments in argv OR while ( i < argc )
	{
		char *argStr = argv[i];
		int len = getLen(argStr);

		if(strCompare(argStr, numStr))
		{
			i++;
			*argStr = argv[i];
			strToInt(argStr);
		} 
		else if(strCompare(argStr, echoStr))
		{
			printf("nope\n");
		}
		else if ((int fd = open(argv[i])) > 0)
		{
			//int fd = openFile(argv[i]);
			if(fd == -1)
			{
				perror("c1");
				exit(1);
			}
			else
			{
				int currBytes = 0;
				//int fileSize = sizeOfFile(argv[i]);
				int bytes = getBytes(fd, currBytes); //read here
				//TODO: read from buffer in a function
				char buffer[bytes - currBytes];
				read(fd, buffer, bytes - currBytes);
				//printf("%d", bytes);

				closeFile(fd);
			}
		}
	}
	return 0;
}

int openFile(char fileName[])
{
	int fd;

	fd = open(fileName, O_RDONLY);

	return fd;
}

int closeFile(int fd)
{
	if(close(fd) < 0)
	{
		perror("c1");
		exit(1); // TODO: 3rd level
	}
	return close(fd);
}

int sizeOfFile(char file[])
{
	struct stat fileStat;

	if(stat(file, &fileStat) != 0)
	{
		return 0;
	}

	return fileStat.st_size;
}

// TODO: Document these OR GET THE FUCK RID OF THEM

bool strCompare(char argStr[], char checkStr[])
{
	int i = 0;
	bool valueStatus = false;

	for(i; !(argStr[i] == '\0' || checkStr[i] == '\0'); i++)
	{
		if(argStr[i] == checkStr[i])
			valueStatus = true;
		else
			valueStatus = false;
	}

	if((argStr[i] == '\0' && checkStr[i] == '\0') && valueStatus)
		return true;
	else	
		return false;
}

size_t str_len(const char *str)
{
    for (size_t len = 0;;++len) if (str[len]==0) return len;
}

void printStuff(char *msg) // using your own print for documented char *s
{
    write(1, msg, str_len(msg));
}

void printData(char *buffer, int len) // give buffer & len from read
{
  write(1, buffer, len);
}

int strToInt(char argStr[])
{
	// https://blog.udemy.com/c-string-to-int/
	// string to int
	printf("lol");
}