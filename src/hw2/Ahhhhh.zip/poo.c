#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

// Gets the length of a given string
size_t str_len (const char *str)
{
    for (size_t len = 0;;++len) if (str[len]==0) return len;
}

// A very convaluted print statement. Once I figure out buffers, I plan on simplifying this
void MandEsPrint(char *msg)
{
    int sizeI = str_len(msg);
    write(STDOUT_FILENO,msg,sizeI);
    char *msg2 = "\n";
    sizeI = str_len(msg2);
    write(STDOUT_FILENO,msg2,sizeI);
}

// returns the amount of bytes in a line.... minus the newline character
// returns: 31, 63, 95 instead of 32, 64, 96
int foo(int fd, int start)
{
    int ct = start;
    int answer = 0;
    char buffer[1];
   while (1)
   {
       lseek(fd, ct, SEEK_SET);
       answer = read(fd, buffer, 1);
       char *val = buffer;
       char *val2 = "\n";
       if (*val == *val2 || buffer == '\0')
       {
           return ct;
       }
       ct++;
   }
}

// Lord only knows what the actual shit is happening here....tis main
int main()
{
    int cuurrentPlace = 0;
    int fd = open("nanpa",O_RDONLY);
    int theAnswer = foo(fd, 0);
    printf("Output: %d\n", theAnswer);

    lseek(fd, cuurrentPlace, SEEK_SET);
    char buffer[theAnswer - cuurrentPlace];
    read(fd, buffer, theAnswer - cuurrentPlace);
    char *output = buffer;
    MandEsPrint(output);
    

    cuurrentPlace = theAnswer + 1;
    theAnswer = foo(fd, cuurrentPlace);
    printf("Output: %d\n", theAnswer);

    lseek(fd, cuurrentPlace, SEEK_SET);
    char buffer2[theAnswer - cuurrentPlace];
    read(fd, buffer2, theAnswer - cuurrentPlace);
    char *output2 = buffer2;
    MandEsPrint(output2);

    return 0;
}